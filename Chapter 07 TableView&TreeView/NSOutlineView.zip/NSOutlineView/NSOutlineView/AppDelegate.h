//
//  AppDelegate.h
//  NSOutlineView
//
//  Created by zhaojw on 15/8/29.
//  Copyright (c) 2015年 zhaojw. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

