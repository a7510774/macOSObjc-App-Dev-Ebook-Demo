//
//  OutlineView.m
//  NSOutlineView
//
//  Created by iDevFans on 2016/11/15.
//  Copyright © 2016年 zhaojw. All rights reserved.
//

#import "OutlineView.h"

@implementation OutlineView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

- (id)makeViewWithIdentifier:(NSString *)identifier owner:(id)owner
{
    id view = [super makeViewWithIdentifier:identifier owner:owner];
    
    if ([identifier isEqualToString:NSOutlineViewDisclosureButtonKey])
    {
        // Do your customization
        // return disclosure button view
        
        [view setImage:[NSImage imageNamed:@"Plus"]];
        [view setAlternateImage:[NSImage imageNamed:@"Minus"]];
        [view setBordered:NO];
        [view setTitle:@""];
        
        return view;
    }
    
    return view;
}

//Frame of the disclosure view
//- (NSRect)frameOfOutlineCellAtRow:(NSInteger)row
//{
//    NSRect frame = NSMakeRect(4, (row * 22), 19, 19);
//    return frame;
//}

@end
