//
//  main.m
//  NSOutlineView
//
//  Created by zhaojw on 15/8/29.
//  Copyright (c) 2015年 zhaojw. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
