//
//  OutlineView.h
//  NSOutlineView
//
//  Created by iDevFans on 2016/11/15.
//  Copyright © 2016年 zhaojw. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface OutlineView : NSOutlineView

@end
